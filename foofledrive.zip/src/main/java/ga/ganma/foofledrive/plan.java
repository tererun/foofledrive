package ga.ganma.foofledrive;

import java.io.Serializable;

public enum plan implements Serializable {
	FREE,LIGHT,MIDDLE,LARGE
}
